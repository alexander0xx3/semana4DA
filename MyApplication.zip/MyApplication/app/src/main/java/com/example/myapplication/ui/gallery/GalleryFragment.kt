package com.example.myapplication.ui.gallery

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.fragment.app.Fragment
import com.example.myapplication.R

class GalleryFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_gallery, container, false)

        val btnToast = root.findViewById<Button>(R.id.btnNotificacionToast)
        val btnNotificacion = root.findViewById<Button>(R.id.btnNotificacionSystem)

        btnToast.setOnClickListener {
            Toast.makeText(requireContext(), "Notificación en pantalla!", Toast.LENGTH_SHORT).show()
        }

        btnNotificacion.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ActivityCompat.checkSelfPermission(
                        requireContext(),
                        android.Manifest.permission.POST_NOTIFICATIONS
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(
                        arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                        1001
                    )
                    return@setOnClickListener
                }
            }
            createNotification()
        }
        return root
    }

    private fun createNotification() {
        val channelId = "canal_notificacion"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Canal Principal",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val notificationManager =
                requireContext().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(requireContext(), channelId)
            .setContentTitle("Título")
            .setContentText("Contenido de la notificación")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()

        NotificationManagerCompat.from(requireContext()).notify(1, notification)
    }
}